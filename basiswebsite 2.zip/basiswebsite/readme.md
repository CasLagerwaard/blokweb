# Procesverslag
**Auteur:** Cas Lagerwaard

Markdown cheat cheet: [Hulp bij het schrijven van Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet). Nb. de standaardstructuur en de spartaanse opmaak zijn helemaal prima. Het gaat om de inhoud van je procesverslag. Besteedt de tijd voor pracht en praal aan je website.



## Bronnenlijst
1. -bron 1-
2. -bron 2-
3. -...-



## Eindgesprek (week 7/8)

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van je eindresultaat-



## Voortgang 3 (week 6)

-same as voortgang 1-



## Voortgang 2 (week 5)

-same as voortgang 1-



## Voortgang 1 (week 3)

### Stand van zaken

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van hoe ver je bent-

### Agenda voor meeting

Hoe kan ik in mijn P element een enter doen? 
Hoe krijg ik images over het hele scherm en zelfs er buiten?
Hoe houd ik mijn tekst goed in het midden? dat was nu met margin en padding..
De background color gaat niet helemaal over de pagina?
de website blijft veranderen hoe maak ik die nu goed na?

### Verslag van meeting

-na afloop snel uitkomsten vastleggen-



## Intake (week 1)

**Je startniveau:** Rood

**Je focus:** Surface plane

**Je opdracht:** https://www.apple.com/nl/?afid=p238%7CsOAYctFNC-dc_mtid_187079nc38483_pcrid_431760065195_pgrid_13316338141_&cid=aos-nl-kwgo-brand--slid--bran-product-

**Screenshot(s):**

![screenshot(s) die een goed beeld geven van de website die je gaat maken](images/schermafbeelding1.png)

**Breakdown-schets(en):**

![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/breakdownschets1.png)
![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/breakdownschets2.png)
